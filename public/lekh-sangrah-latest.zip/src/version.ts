// Application Version Configuration
// તમે જ્યારે પણ કહો ત્યારે આ ફાઇલમાં વર્ઝન નંબર બદલવાથી તમામ ડિવાઇસ પર નવો નંબર દેખાશે.
export const APP_VERSION = 'v2.5.0';
export const APP_BUILD_DATE = '2026-09-30';
